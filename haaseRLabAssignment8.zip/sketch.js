let grid = [];
let size = 3;
let square1 = false;
let square2 = false;
let square3 = false;
let square4 = false;
let square5 = false;
let square6 = false;
let square7 = false;
let square8 = false;
let square9 = false;
let tracker = false;
let x = -1;
let y = -1;

function preload(){
  x = loadImage('assets/X.png'); //X.png from nicepng.com
  o = loadImage('assets/O.png'); //O.png from pngimg.com
}
function setup() {
  background(220);
  createCanvas(400, 400);
  textFont('Arial');
  textSize(20);
  for(let i=0; i<size; i++){
    grid[i] = [];
  }
}

function draw() {
  //Set up board
  background(220);
  line(133, 0, 133, 400);
  line(266, 0, 266, 400);
  line(0, 133, 400, 133);
  line(0, 266, 400, 266);
  //Draw symbols from array
  if(grid[0][0] == 'X'){
    image(x, 17, 17);
  }
  else if(grid[0][0]=='O'){
    image(o, 17, 17);
  }
  if(grid[1][0] == 'X'){
    image(x, 150, 17);
  }
  else if(grid[1][0] == 'O'){
    image(o, 150, 17);
  }
  if(grid[2][0] == 'X'){
    image(x, 283, 17);
  }
  else if(grid[2][0] == 'O'){
    image(o, 283, 17);
  }
  if(grid[0][1] == 'X'){
    image(x, 17, 150);
  }
  else if(grid[0][1] == 'O'){
    image(o, 17, 150);
  }
  if(grid[1][1] == 'X'){
    image(x, 150, 150);
  }
  else if(grid[1][1] == 'O'){
    image(o, 150, 150);
  }
  if(grid[2][1] == 'X'){
    image(x, 283, 150);
  }
  else if(grid[2][1] == 'O'){
    image(o, 283, 150);
  }
  if(grid[0][2] == 'X'){
    image(x, 17, 283);
  }
  else if(grid[0][2] == 'O'){
    image(o, 17, 283);
  }
  if(grid[1][2] == 'X'){
    image(x, 150, 283);
  }
  else if(grid[1][2] == 'O'){
    image(o, 150, 283);
  }
  if(grid[2][2] == 'X'){
    image(x, 283, 283);
  }
  else if(grid[2][2] == 'O'){
    image(o, 283, 283);
  }
//Check for win
  //Top Row
  if(grid[0][0]!=null && grid[0][0]==grid[1][0] && grid[0][0] == grid[2][0]){
    if(grid[0][0] == 'X'){  
      scale(1.5);
      image(x, -5, -5);
      image(x, 85, -5);
      image(x, 175, -5);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[0][0] == 'O'){
      scale(1.5);
      image(o, -5, -5);
      image(o, 85, -5);
      image(o, 175, -5);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
  //Middle Row
  if(grid[0][1]!=null && grid[0][1]==grid[1][1] && grid[0][1] == grid[2][1]){
    if(grid[0][1] == 'X'){  
      scale(1.5);
      image(x, -5, 85);
      image(x, 85, 85);
      image(x, 175, 85);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[0][1] == 'O'){
      scale(1.5);
      image(o, -5, 85);
      image(o, 85, 85);
      image(o, 175, 85);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
  //Bottom Row
  if(grid[0][2]!=null && grid[0][2]==grid[1][2] && grid[0][2] == grid[2][2]){
    if(grid[0][2] == 'X'){  
      scale(1.5);
      image(x, -5, 175);
      image(x, 85, 175);
      image(x, 175, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[0][2] == 'O'){
      scale(1.5);
      image(o, -5, 175);
      image(o, 85, 175);
      image(o, 175, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
  //Left Column
  if(grid[0][0]!=null && grid[0][0]==grid[0][1] && grid[0][0]==grid[0][2]){
    if(grid[0][0] == 'X'){  
      scale(1.5);
      image(x, -5, -5);
      image(x, -5, 85);
      image(x, -5, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[0][0] == 'O'){
      scale(1.5);
      image(o, -5, -5);
      image(o, -5, 85);
      image(o, -5, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
  //Middle Column
  if(grid[1][0]!=null && grid[1][0]==grid[1][1] && grid[1][0]==grid[1][2]){
    if(grid[1][0] == 'X'){ 
      scale(1.5);
      image(x, 85, -5);
      image(x, 85, 85);
      image(x, 85, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[1][0] == 'O'){
      scale(1.5);
      image(o, 85, -5);
      image(o, 85, 85);
      image(o, 85, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
  //Right Column
  if(grid[2][0]!=null && grid[2][0]==grid[2][1] && grid[2][0]==grid[2][2]){
    if(grid[2][0] == 'X'){
      scale(1.5);
      image(x, 175, -5);
      image(x, 175, 85);
      image(x, 175, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[2][0] == 'O'){
      scale(1.5);
      image(o, 175, -5);
      image(o, 175, 85);
      image(o, 175, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
  //Left Diagonal
  if(grid[0][0]!=null && grid[0][0]==grid[1][1] && grid[0][0]==grid[2][2]){
    if(grid[0][0] == 'X'){  
      scale(1.5);
      image(x, -5, -5);
      image(x, 85, 85);
      image(x, 175, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[0][0] == 'O'){
      scale(1.5);
      image(o, -5, -5);
      image(o, 85, 85);
      image(o, 175, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
  //Right Diagonal
  if(grid[2][0]!=null && grid[2][0]==grid[1][1] && grid[2][0]==grid[0][2]){
    if(grid[2][0] == 'X'){  
      scale(1.5);
      image(x, 175, -5);
      image(x, 85, 85);
      image(x, -5, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('X Player wins!', 136, 200, 150, 50);
      noLoop();
    }
    else if(grid[2][0] == 'O'){
      scale(1.5);
      image(o, 175, -5);
      image(o, 85, 85);
      image(o, -5, 175);
      scale(0.666);
      fill(255);
      strokeWeight(2);
      stroke(0);
      text('O Player wins!', 136, 200, 150, 50);
      noLoop();
    }
  }
}
  //Function that adds symbols to the array based on where is clicked, also tracks turn
  function mouseClicked(){
    if(square1==false && mouseX>=0 && mouseX<133 && mouseY>=0 && mouseY<133){
      if(tracker==false){
        grid[0][0] = 'X';
        square1 = true;
        tracker = true;
      }
      else{
        grid[0][0] = 'O';
        square1 = true;
        tracker = false;
      }
    }
    else if(square2==false && mouseX>=133 && mouseX<266 && mouseY>=0 && mouseY<133){
      if(tracker==false){
        grid[1][0] = 'X'
        square2 = true;
        tracker = true;
      }
      else{
        grid[1][0] = 'O';
        square2 = true;
        tracker = false;
      }
    }
    else if(square3==false && mouseX>=266 && mouseY<=400 && mouseY>=0 && mouseY<133){
      if(tracker==false){
        grid[2][0] = 'X';
        square3 = true;
        tracker = true;
      }
      else{
        grid[2][0] = 'O';
        square3 = true;
        tracker = false;
      }
    }
    else if(square4==false && mouseX>=0 && mouseX<133 && mouseY>=133 && mouseY<266){
      if(tracker==false){
        grid[0][1] = 'X';
        square4 = true;
        tracker = true;
      }
      else{
        grid[0][1] = 'O';
        square4 = true;
        tracker = false;
      }
    }
    else if(square5==false && mouseX>=133 && mouseX<266 && mouseY>=133 && mouseY<266){
      if(tracker==false){
        grid[1][1] = 'X';
        square5 = true;
        tracker = true;
      }
      else{
        grid[1][1] = 'O';
        square5 = true;
        tracker = false;
      }
    }
    else if(square6==false && mouseX>=266 && mouseX<=400 && mouseY>=133 && mouseY<266){
      if(tracker==false){
        grid[2][1] = 'X';
        square6 = true;
        tracker = true;
      }
      else{
        grid[2][1] = 'O';
        square6 = true;
        tracker = false;
      }
    }
    else if(square7==false && mouseX>=0 && mouseX<133 && mouseY>=266 && mouseY<=400){
      if(tracker==false){
        grid[0][2] = 'X';
        square7 = true;
        tracker = true;
      }
      else{
        grid[0][2] = 'O';
        square7 = true;
        tracker = false;
      }
    }
    else if(square8==false && mouseX>=133 && mouseX<266 && mouseY>=266 && mouseY<=400){
      if(tracker==false){
        grid[1][2] = 'X';
        square8 = true;
        tracker = true;
      }
      else{
        grid[1][2] = 'O';
        square8 = true;
        tracker = false;
      }
    }
    else if(square9==false && mouseX>=266 && mouseX<=400 && mouseY>=266 && mouseY<=400){
      if(tracker==false){
        grid[2][2] = 'X';
        square9 = true;
        tracker = true;
      }
      else{
        grid[2][2] = 'O';
        square9 = true;
        tracker = false;
      }
    }
  }