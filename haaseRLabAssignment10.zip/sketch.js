var boardRadius = 10;
var size;
var originHex;
var hexes = [];
var mainLayout;
var hex;

function setup()
{
  createCanvas(500, 500);
  background(225);
  angleMode(degrees);
  size = Point(12, 12);
  originPixel = Point(width/2, height/2);
  mainLayout = hexLayout(pointyOrient, size, originPixel)
  hexGenerateBoard(boardRadius, hexes, Hex(0,0,0));
  originHex = Hex(0,0,0);
}

function draw()
{
  stroke(0);
  background(225);
  translate(width/2, height/2);
  fill('white');
  hexDrawArray(mainLayout, hexes);
  fill('green');
  hexDraw(mainLayout, Hex(0, 0, 0));
  fill('blue');
  hexDraw(mainLayout, Hex(1, -1, 0));
  hexDraw(mainLayout, Hex(1, -2, 1));
  hexDraw(mainLayout, Hex(0, -2, 2));
  fill('grey');
  hexDraw(mainLayout, Hex(-1, 1, 0));
	
}