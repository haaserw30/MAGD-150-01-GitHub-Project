let ghostPosition = [];
let numGhosts = 3;
//let ghostY = 200;
let ghostW = 50;
let ghostH = 150;
function setup() {
  createCanvas(400, 400);
  for(let i=0; i<numGhosts; i++){
    ghostPosition[i] = [];
    for(let j=0; j<2; j++){
      ghostPosition[i][j] = -1;
    }
  }
    console.log(ghostPosition.length);
}

function draw() {
  background(20);
  //moon
  fill(250, 250, 200);
  circle(200, 200, 300);
  ghostPosition[ghostPosition.length-1][0] = mouseX - 50;
  ghostPosition[ghostPosition.length-1][1] = mouseY + 50;
  for(let k=0; k<ghostPosition.length-1; k++){
    for(let l=0; l<2; l++){
      ghostPosition[k][l] = ghostPosition[k+1][l];
    }
  }
  for(let i=0; i<numGhosts; i++){
        ghostPosition[i][0] = ghostPosition[i][0] + random (-10, 10);
    ghostPosition[i][1] = ghostPosition[i][1] + random (-10, 10);
         //ghost
  fill(250);
  arc(ghostPosition[i][0], ghostPosition[i][1], ghostW, ghostH, PI, PI * 2, OPEN);
  //eyes
  fill(0);
  ellipse(ghostPosition[i][0]-5, ghostPosition[i][1]-50, 5, 10);
  ellipse(ghostPosition[i][0]+5, ghostPosition[i][1]-50, 5, 10);
  ellipse(ghostPosition[i][0], ghostPosition[i][1]-30, 10, 10);
  }
    //pumpkin
  fill(200, 130, 0);
  ellipse(mouseX, mouseY, 30, 20);
  ellipse(mouseX, mouseY, 20, 20);
  ellipse(mouseX, mouseY, 10, 20);
  fill(0, 100, 0);
  rect(mouseX, mouseY-13, 2, 5);


    /* //ghost
  fill(250);
  arc(ghostX, ghostY, ghostW, ghostH, PI, PI * 2, OPEN);
  //eyes
  fill(0);
  ellipse(ghostX-5, ghostY-50, 5, 10);
  ellipse(ghostX+5, ghostY-50, 5, 10);
  ellipse(ghostX, ghostY-30, 10, 10);*/
}